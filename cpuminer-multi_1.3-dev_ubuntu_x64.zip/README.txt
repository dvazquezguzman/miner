# to run cpuminer and load settings from example cpuminer-conf.json.lyra2re configuration file issue this command:
./cpuminer -c cpuminer-conf.json.lyra2re

For more informations visit:
https://www.nicehash.com/index.jsp?p=software#cpu